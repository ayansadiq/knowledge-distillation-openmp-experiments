import jax
import jax.numpy as jnp

class RMSNorm:
    def __init__(self, dim: int, eps: float = 1e-8):
        self.eps = eps
        self.scale = jnp.ones(dim)

    def __call__(self, x: jnp.ndarray) -> jnp.ndarray:
        norm = jnp.sqrt(
            jnp.mean(x ** 2, axis=-1, keepdims=True) + self.eps
        )
        return (x / norm) * self.scale

x = jax.random.normal(
    jax.random.PRNGKey(0), shape=(3, 5)
)
rmsnorm = RMSNorm(dim=5)
out = rmsnorm(x)
print(out.shape)
assert out.shape == (3, 5), "Output shape mismatch"
